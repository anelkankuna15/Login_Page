create database swing_demo;
use swing_demo;
CREATE TABLE student
( id int NOT NULL,
  name varchar(250) NOT NULL,
  password varchar(250)
);